import argparse
import json
from pathlib import Path
import re
import sys
from typing import Dict, Tuple, Set, List, Optional

from jinja2 import Environment, FileSystemLoader, StrictUndefined, TemplateError, Undefined
import random
import string
import pandas as pd
import openpyxl


# Rendering (Jinja2)

def generate_random_value() -> str:
    return '{VALUE}'

class SoftUndefined:
    def __init__(self, name="undefined"):
        self._name = name
    
    def __str__(self):
        return generate_random_value()
    
    def __repr__(self):
        return generate_random_value()
    
    def __bool__(self):
        return True
    
    def __eq__(self, other):
        return True
    
    def __ne__(self, other):
        return False
    
    def __getattr__(self, name):
        return SoftUndefined(name=f"{self._name}.{name}")
    
    def __getitem__(self, key):
        return SoftUndefined(name=f"{self._name}.{key}")
    
    def __iter__(self):
        return iter([SoftUndefined(name=f"{self._name}_item")])
    
    def __len__(self):
        return 1


class SoftUndefinedHandler(Undefined):
    def __new__(cls, hint=None, obj=None, name=None, exc=None):
        return SoftUndefined(name=name or "undefined")

def load_and_render_templates(
    templates_dir: Path,
    vars_for_device: dict,
    compliance_mode: str = "enforced",
) -> str:
    undefined_class = SoftUndefinedHandler if compliance_mode == "soft" else StrictUndefined
    
    env = Environment(
        loader=FileSystemLoader(str(templates_dir)),
        undefined=undefined_class,
        keep_trailing_newline=True,
        trim_blocks=False,
        lstrip_blocks=False,
        autoescape=False,
    )

    rendered_parts: List[str] = []
    for tpl_path in sorted(templates_dir.glob("*.j2")):
        try:
            template = env.get_template(tpl_path.name)
            rendered = template.render(**vars_for_device)
        except TemplateError as e:
            raise SystemExit(f"[Jinja] Error rendering {tpl_path.name}: {e}") from e
        rendered_parts.append(rendered)

    return "\n".join(rendered_parts)


# Parsing → Stanzas

StanzaKey = Tuple[Tuple[str, ...], Tuple[str, ...]]  

def parse_into_stanzas(config_text: str) -> Dict[StanzaKey, Set[str]]:
    stanzas: Dict[StanzaKey, Set[str]] = {}

    config_stack: List[str] = []  
    edit_stack: List[str] = []   
    current_lines: List[str] = []

    lines = config_text.splitlines()

    def stanza_key() -> Optional[StanzaKey]:
        if not config_stack:
            return None
        parts: List[str] = []
        for c in config_stack:
            parts.extend(c.strip().split())
        return (tuple(parts), tuple(edit_stack))

    for raw_line in lines:
        line = raw_line.strip()

        if not line or line.startswith("#"):
            continue

        if line.lower().startswith("config "):
            config_stack.append(line)
            key = stanza_key()
            if key is not None and key not in stanzas:
                stanzas[key] = set()
            continue

        if line.lower().startswith("end"):
            if config_stack:
                config_stack.pop()
            else:
                pass
            continue

        if line.lower().startswith("edit "):
            edit_stack.append(line)
            key = stanza_key()
            if key is not None and key not in stanzas:
                stanzas[key] = set()
            continue

        if line.lower().startswith("next"):
            if edit_stack:
                edit_stack.pop()
            else:
                pass
            continue

        if line.lower().startswith("set "):
            key = stanza_key()
            if key is None:
                continue
            norm = normalize_set_line(line)
            if norm:
                stanzas.setdefault(key, set()).add(norm)


    return stanzas


# Normalization

_ws_re = re.compile(r"\s+")

def normalize_set_line(line: str) -> Optional[str]:
    s = line.strip()
    if not s.lower().startswith("set "):
        return None

    parts = s.split(None, 2)
    if len(parts) < 3:
        return None
    _, key, rest = parts
    key = key.lower().strip()

    vals = tokenize_values(rest)

    norm_vals = [normalize_value_token(tok) for tok in vals]

    return "set " + key + " " + " ".join(norm_vals)


def tokenize_values(s: str) -> List[str]:
    tokens: List[str] = []
    i = 0
    n = len(s)
    while i < n:
        if s[i].isspace():
            i += 1
            continue
        if s[i] == '"':
            j = i + 1
            while j < n and s[j] != '"':
                j += 1
            tokens.append(s[i:j+1] if j < n else s[i:])
            i = (j + 1) if j < n else n
        else:
            j = i
            while j < n and not s[j].isspace():
                j += 1
            tokens.append(s[i:j])
            i = j
    return tokens


_simple_value_re = re.compile(r"^[A-Za-z0-9._:/\-@]+$")


def normalize_edit(edit_line: str) -> str:
    """Normalize an edit line by removing quotes from simple identifiers.
    
    Examples:
        'edit "admin"' -> 'edit admin'
        'edit "1"' -> 'edit 1'
        'edit admin' -> 'edit admin'
        'edit "name with space"' -> 'edit "name with space"'
    """
    s = edit_line.strip()
    if not s.lower().startswith("edit "):
        return s
    
    parts = s.split(None, 1)
    if len(parts) < 2:
        return s
    
    identifier = parts[1].strip()
    
    # Remove quotes if it's a simple identifier
    if identifier.startswith('"') and identifier.endswith('"') and len(identifier) >= 2:
        inner = identifier[1:-1]
        if inner and _simple_value_re.match(inner):
            return f"edit {inner}"
    
    return s


def normalize_value_token(tok: str) -> str:
    t = tok.strip()
    if not t:
        return t

    if t.startswith('"') and t.endswith('"') and len(t) >= 2:
        inner = t[1:-1]
        if inner and _simple_value_re.match(inner):
            return inner
        return f'"{inner}"'

    if " " in t or "\t" in t:
        return f'"{_ws_re.sub(" ", t).strip()}"'
    return t


# Soft compliance: extract structure without values

def extract_command_structure(line: str) -> Optional[str]:
    s = line.strip()
    if not s.lower().startswith("set "):
        return None
    
    parts = s.split(None, 2)  
    if len(parts) < 2:
        return None
    
    return f"{parts[0].lower()} {parts[1].lower()}"


# Comparison: subset (target ⊆ device)

class ComparisonResult:
    def __init__(self) -> None:
        self.missing_stanzas: List[Tuple[str, List[str]]] = []  # (stanza_name, expected_lines)
        self.missing_lines: List[str] = []
        self.mismatches: List[Tuple[str, str, str]] = []  # reserved (not used in pure subset)
        self.ok = True

    def mark_fail(self):
        self.ok = False


def compare_subset(
    target: Dict[StanzaKey, Set[str]],
    device: Dict[StanzaKey, Set[str]],
    compliance_mode: str = "enforced",
) -> ComparisonResult:
    res = ComparisonResult()
    
    # Normalize device stanzas and merge lines with same normalized key
    normalized_device: Dict[StanzaKey, Set[str]] = {}
    for d_key, d_lines in device.items():
        norm_key = normalize_stanza_key(d_key)
        if norm_key not in normalized_device:
            normalized_device[norm_key] = set()
        normalized_device[norm_key].update(d_lines)

    for t_key, t_lines in target.items():
        if not t_lines:
            continue

        norm_t_key = normalize_stanza_key(t_key)
        
        if norm_t_key not in normalized_device:
            human_key = humanize_stanza_key(t_key)
            expected_lines = list(t_lines)  
            res.missing_stanzas.append((human_key, expected_lines))
            res.mark_fail()
            continue

        d_lines = normalized_device[norm_t_key]
        
        for line in t_lines:
            line_found = False
            
            if compliance_mode == "enforced":
                line_found = line in d_lines
            elif compliance_mode == "soft":
                target_structure = extract_command_structure(line)
                if target_structure:
                    for d_line in d_lines:
                        device_structure = extract_command_structure(d_line)
                        if device_structure and target_structure == device_structure:
                            line_found = True
                            break
                else:
                    line_found = line in d_lines
            
            if not line_found:
                res.missing_lines.append(f"{humanize_stanza_key(t_key)} :: {line}")
                res.mark_fail()

    return res


def normalize_stanza_key(key: StanzaKey) -> StanzaKey:
    """
    Removes 'config global' wrapper
    Removes 'config vdom' wrapper and first VDOM edit
    Removes quotes from simple values (in edits)
    """
    cfg_path, edits = key
    cfg_list = list(cfg_path)
    
    # Normalize all edits by removing quotes from simple identifiers
    normalized_edits = [normalize_edit(e) for e in edits]
    
    # Handle 'config global' wrapper (case-insensitive)
    if len(cfg_list) >= 2 and cfg_list[0].lower() == "config" and cfg_list[1].lower() == "global":
        cfg_list = cfg_list[2:]
        return (tuple(cfg_list), tuple(normalized_edits))
    
    # Handle 'config vdom' wrapper (case-insensitive)
    if len(cfg_list) >= 2 and cfg_list[0].lower() == "config" and cfg_list[1].lower() == "vdom":
        cfg_list = cfg_list[2:]
        
        # Remove the first edit (VDOM name like 'edit root' or 'edit "production"')
        if normalized_edits and len(normalized_edits) > 0:
            first_edit = normalized_edits[0].strip().lower()
            if first_edit.startswith('edit '):
                normalized_edits = normalized_edits[1:]
        
        return (tuple(cfg_list), tuple(normalized_edits))
    
    return (tuple(cfg_list), tuple(normalized_edits))

def humanize_stanza_key(key: StanzaKey) -> str:
    cfg_path, edits = key
    cfg_str = " ".join(cfg_path)
    if edits:
        return f'{cfg_str} -> {" / ".join(edits)}'
    return cfg_str



def load_vars_json(path: Optional[Path]) -> dict:
    if not path:
        return {"global": {}, "devices": {}}
    
    with path.open("r", encoding="utf-8") as f:
        data = json.load(f)
    if not isinstance(data, dict):
        raise SystemExit("--vars-json must be an object with optional 'global' and 'devices'")
    data.setdefault("global", {})
    data.setdefault("devices", {})
    return data


def merge_vars_for_device(vars_json: dict, device_name: str) -> dict:
    merged = dict(vars_json.get("global", {}))
    dev = (vars_json.get("devices") or {}).get(device_name, {})
    if dev:
        merged.update(dev)
    merged.setdefault("device_name", device_name)
    return merged


# Reporting

def print_report(device_name: str, result: ComparisonResult) -> None:
    hdr = f"DEVICE {device_name}"
    print("\n" + "=" * len(hdr))
    print(hdr)
    print("=" * len(hdr))
    if result.ok:
        print("COMPLIANT")
        return

    print("NON-COMPLIANT")
    if result.missing_stanzas:
        print("\nCompletely missing stanzas:")
        for stanza_name, expected_lines in result.missing_stanzas:
            print(f"  - {stanza_name}")
            print(f"    Expected lines:")
            for line in expected_lines:
                print(f"      * {line}")

    if result.missing_lines:
        print("\nMissing lines in existing stanzas:")
        for m in result.missing_lines:
            print(f"  - {m}")


def create_excel_report(target_stanzas: Dict[StanzaKey, Set[str]], 
                       device_results: Dict[str, Dict[StanzaKey, Set[str]]], 
                       output_file: str = "compliance_report.xlsx",
                       compliance_mode: str = "enforced") -> None:
    rows = []
    device_names = sorted(device_results.keys())
    
    normalized_target_stanzas: Dict[StanzaKey, Set[str]] = {}
    for stanza_key, target_lines in target_stanzas.items():
        if not target_lines:  # Skip empty stanzas
            continue
        
        normalized_key = normalize_stanza_key(stanza_key)
        if normalized_key not in normalized_target_stanzas:
            normalized_target_stanzas[normalized_key] = set()
        normalized_target_stanzas[normalized_key].update(target_lines)
    
    normalized_device_results = {}
    for device_name in device_names:
        normalized_device_results[device_name] = {}
        for d_key, d_lines in device_results[device_name].items():
            norm_key = normalize_stanza_key(d_key)
            if norm_key not in normalized_device_results[device_name]:
                normalized_device_results[device_name][norm_key] = set()
            normalized_device_results[device_name][norm_key].update(d_lines)
    
    for normalized_key, target_lines in normalized_target_stanzas.items():
        stanza_name = humanize_stanza_key(normalized_key)
        sorted_lines = sorted(target_lines)  
        
        for i, line in enumerate(sorted_lines):
            row = {}
            
            row['Stanza'] = stanza_name if i == 0 else ""
            
            row['Configuration Line'] = line

            compliant_count = 0
            total_devices = len(device_names)
            
            for device_name in device_names:
                norm_device_stanzas = normalized_device_results[device_name]
                
                line_found = False
                
                if normalized_key in norm_device_stanzas:
                    device_lines = norm_device_stanzas[normalized_key]
                    
                    if compliance_mode == "enforced":
                        line_found = line in device_lines
                    elif compliance_mode == "soft":
                        target_structure = extract_command_structure(line)
                        if target_structure:
                            for d_line in device_lines:
                                device_structure = extract_command_structure(d_line)
                                if device_structure and target_structure == device_structure:
                                    line_found = True
                                    break
                        else:
                            line_found = line in device_lines
                
                row[device_name] = "O" if line_found else "X"
                if line_found:
                    compliant_count += 1
            
            row['Compliance Count'] = f"{compliant_count}/{total_devices}"
            rows.append(row)
    
    compliance_percentages = {}
    total_lines = len(rows)
    
    if total_lines > 0:
        for device_name in device_names:
            compliant_count = sum(1 for row in rows if row[device_name] == "O")
            compliance_percentages[device_name] = (compliant_count / total_lines) * 100
    
    percentage_row = {
        'Stanza': 'COMPLIANCE PERCENTAGE',
        'Configuration Line': ''
    }
    for device_name in device_names:
        percentage = compliance_percentages.get(device_name, 0)
        percentage_row[device_name] = f"{percentage:.1f}%"
    percentage_row['Compliance Count'] = ''

    rows.append(percentage_row)
    
    df = pd.DataFrame(rows)
    
    columns = ['Stanza', 'Configuration Line'] + device_names + ['Compliance Count']
    df = df[columns]
    
    with pd.ExcelWriter(output_file, engine='openpyxl') as writer:
        df.to_excel(writer, sheet_name='Compliance Report', index=False)
        
        worksheet = writer.sheets['Compliance Report']
        for column in worksheet.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(str(cell.value))
                except:
                    pass
            adjusted_width = min(max_length + 2, 50)  
            worksheet.column_dimensions[column_letter].width = adjusted_width
        
        mode_description = "Enforced Compliance (exact values)" if compliance_mode == "enforced" else "Soft Compliance (structure only)"
        worksheet.insert_rows(1)
        worksheet['A1'] = f"Compliance mode: {mode_description}"
        from openpyxl.styles import Font, PatternFill, Alignment
        worksheet['A1'].font = Font(bold=True)
        
        last_row = worksheet.max_row
        for col in range(1, worksheet.max_column + 1):
            cell = worksheet.cell(row=last_row, column=col)
            cell.font = Font(bold=True)
            cell.alignment = Alignment(horizontal="center")
    
    print(f"Excel compliance report created: {Path(output_file).resolve()}")
    print(f"Mode: {'Enforced (exact values)' if compliance_mode == 'enforced' else 'Soft (structure only)'}")



def main():
    ap = argparse.ArgumentParser(description="FortiGate config compliance: Render -> Normalize -> Subset -> Excel Report")
    ap.add_argument("--devices-json", required=True, type=Path,
                    help="Path to JSON { device_name: device_config_text, ... }")
    ap.add_argument("--templates-dir", required=True, type=Path,
                    help="Directory containing *.j2 Jinja templates")
    ap.add_argument("--vars-json", required=False, type=Path,
                    help="JSON with 'global' and per-device variables (optional in soft mode)")
    ap.add_argument("--output-excel", required=False, type=str, default="compliance_report.xlsx",
                    help="Output Excel file name (default: compliance_report.xlsx)")
    ap.add_argument("--compliance-mode", required=False, type=str, 
                    choices=["enforced", "soft"], default="enforced",
                    help="Compliance mode: 'enforced' (exact values) or 'soft' (structure only)")
    args = ap.parse_args()

    if not args.devices_json.exists():
        sys.exit(f"devices file not found: {args.devices_json}")
    if not args.templates_dir.exists():
        sys.exit(f"templates dir not found: {args.templates_dir}")

    with args.devices_json.open("r", encoding="utf-8") as f:
        devices_map = json.load(f)
    if not isinstance(devices_map, dict):
        sys.exit("--devices-json must be a JSON object with hierarchy: {fortimanager_ip: {adom: {device_name: {config: config_text}}}}")

    vars_json = load_vars_json(args.vars_json)
    
    if not args.vars_json and args.compliance_mode == "soft":
        print("[INFO] Soft mode without vars-json, only command structure matters (values ignored)")

    device_results = {}
    target_stanzas = None
    
    for fortimanager_ip, adoms in devices_map.items():
        if not isinstance(adoms, dict):
            print(f"[WARN] FortiManager {fortimanager_ip} data is not a dict; skipping")
            continue
            
        for adom_name, devices in adoms.items():
            if not isinstance(devices, dict):
                print(f"[WARN] ADOM {adom_name} data is not a dict; skipping")
                continue
                
            for device_name, device_data in devices.items():
                if not isinstance(device_data, dict) or 'config' not in device_data:
                    print(f"[WARN] device {device_name} data is missing 'config' key; skipping")
                    continue
                    
                device_text = device_data['config']
                if not isinstance(device_text, str):
                    print(f"[WARN] device {device_name} config is not a string; skipping")
                    continue

                print(f"Processing device: {device_name}")
                
                device_text = device_text.replace('\\n', '\n')
                vars_for_device = merge_vars_for_device(vars_json, device_name)
                target_text = load_and_render_templates(args.templates_dir, vars_for_device, args.compliance_mode)

                current_target_stanzas = parse_into_stanzas(target_text)
                device_stanzas = parse_into_stanzas(device_text)
                
                if target_stanzas is None:
                    target_stanzas = current_target_stanzas
                
                device_results[device_name] = device_stanzas

    if target_stanzas and device_results:
        create_excel_report(target_stanzas, device_results, args.output_excel, args.compliance_mode)
        print(f"Processing completed. {len(device_results)} devices analyzed.")
        print(f"Compliance mode used: {args.compliance_mode}")
    else:
        print("No data to process.")


if __name__ == "__main__":
    main()