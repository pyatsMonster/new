import argparse
import json
import os
import glob
import sys


def main():
    parser = argparse.ArgumentParser(description="Assemble device configs into devices.json")
    parser.add_argument("--devices-json", required=True, help="Path to devices.json (read+write)")
    parser.add_argument("--config-dir", required=True, help="Directory containing {adom}___{device}.conf files")
    args = parser.parse_args()

    with open(args.devices_json) as f:
        tree = json.load(f)

    loaded = 0
    skipped = 0
    for filepath in sorted(glob.glob(os.path.join(args.config_dir, "*.conf"))):
        basename = os.path.basename(filepath).rsplit(".conf", 1)[0]
        parts = basename.split("___", 1)
        if len(parts) != 2:
            print(f"WARNING: skipping invalid filename: {os.path.basename(filepath)}", file=sys.stderr)
            skipped += 1
            continue
        adom, device = parts
        with open(filepath) as cf:
            config_content = cf.read()
        if not config_content.strip():
            print(f"WARNING: empty config for {device} in {adom}", file=sys.stderr)
            skipped += 1
            continue
        found = False
        for fmg in tree:
            if adom in tree[fmg] and device in tree[fmg][adom]:
                tree[fmg][adom][device]["config"] = config_content
                loaded += 1
                found = True
                break
        if not found:
            print(f"WARNING: device {device} / ADOM {adom} not found in tree", file=sys.stderr)
            skipped += 1

    with open(args.devices_json, "w") as f:
        json.dump(tree, f, indent=2)

    print(f"Loaded {loaded} device configurations into {args.devices_json} ({skipped} skipped)")


if __name__ == "__main__":
    main()